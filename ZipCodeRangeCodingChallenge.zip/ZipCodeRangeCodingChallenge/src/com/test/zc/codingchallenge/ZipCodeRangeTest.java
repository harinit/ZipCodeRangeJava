/**
 * 
 */
package com.test.zc.codingchallenge;

import static org.junit.Assert.*;

import org.junit.Test;

import com.zc.codingchallenge.ZipCodeRange;

/**
 * @author harinit99
 *
 */
public class ZipCodeRangeTest {

	/**
	 * No overlapping ranges
	 * 
	 * @throws Exception
	 */
	@Test
	public void testForInputSet1() throws Exception {
		int[][] input = new int[][] { { 94133, 94133 }, { 94200, 94299 }, { 94600, 94699 } };
		int[][] expected = new int[][] { { 94133, 94133 }, { 94200, 94299 }, { 94600, 94699 } };
		int[][] result = new int[3][2];
		result = ZipCodeRange.reduceZipCodeRange(input);
		assertArrayEquals(expected, result);
	}

	/**
	 * One Overlapping Range
	 * 
	 * @throws Exception
	 */
	@Test
	public void testForInputSet2() throws Exception {
		int[][] input = new int[][] { { 94133, 94133 }, { 94200, 94299 }, { 94226, 94399 } };
		int[][] expected = new int[][] { { 94133, 94133 }, { 94200, 94399 } };
		int[][] result = new int[2][2];
		result = ZipCodeRange.reduceZipCodeRange(input);
		assertArrayEquals(expected, result);
	}

	/**
	 * All are of same range
	 * 
	 * @throws Exception
	 */
	@Test
	public void testForInputSet3() throws Exception {

		int[][] input = new int[][] { { 11111, 11111 }, { 11111, 11111 }, { 11111, 11111 } };
		int[][] expected = new int[][] { { 11111, 11111 } };
		int[][] result = new int[1][1];
		result = ZipCodeRange.reduceZipCodeRange(input);
		assertArrayEquals(expected, result);
	}

	/**
	 * Specified ranges differ by one value
	 * 
	 * @throws Exception
	 */
	@Test
	public void testForInputSet4() throws Exception {

		int[][] input = new int[][] { { 11111, 11111 }, { 11112, 11113 }, { 11117, 11118 }, { 11111, 11111 },
				{ 11110, 11119 }, { 10000, 20000 } };
		int[][] expected = new int[][] { { 10000, 20000 } };
		int[][] result = new int[1][1];
		result = ZipCodeRange.reduceZipCodeRange(input);
		assertArrayEquals(expected, result);
	}

	/**
	 * Specified ranges backwards
	 * 
	 * @throws Exception
	 */
	@Test
	public void testForInputSet5() throws Exception {

		int[][] input = new int[][] { { 31111, 11111 }, { 11111, 31111 }, { 11110, 11111 }, { 11117, 10000 },
				{ 11110, 11119 }, { 33116, 35112 } };
		int[][] expected = new int[][] { { 10000, 31111 }, { 33116, 35112 } };
		int[][] result = new int[1][1];
		result = ZipCodeRange.reduceZipCodeRange(input);
		assertArrayEquals(expected, result);
	}

	/**
	 * Exception scenario if zip code is not for 5 digits
	 * 
	 * @throws Exception
	 */
	@Test(expected = Exception.class)
	public void testForInputSet6() throws Exception {
		int[][] input = new int[][] { { 355, 10 }, { 110, 13 }, { 0, 0 }, { 15, 3 } };
		ZipCodeRange.reduceZipCodeRange(input);
	}

	/**
	 * Exception scenario if zip code is not for 3-6 digits
	 * 
	 * @throws Exception
	 */
	@Test(expected = Exception.class)
	public void testForInputSet7() throws Exception {
		int[][] input = new int[][] { { 5, 10 }, { 932002, 30 }, { 705, 100 }, { 9, 1000 } };
		ZipCodeRange.reduceZipCodeRange(input);
	}

}
