/**
 * 
 */
package com.zc.codingchallenge;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author harinit99 Time Complexity : O(n) Space Complexity: O(n)
 */
public class ZipCodeRange {
	/**
	 * This method will take the input and validate it first. Later, using TreeMap
	 * we are ordering the elements by taking the smaller value as the Key
	 * 
	 * @param input
	 * @return
	 * @throws Exception
	 */
	public static int[][] reduceZipCodeRange(int[][] input) throws Exception {

		validateZipCode(input);

		TreeMap<Integer, Integer> zipCodeMap = new TreeMap<>();

		for (int[] keyValue : input) {

			// Find the smaller value and set it as key
			int key = keyValue[1] < keyValue[0] ? keyValue[1] : keyValue[0];
			int value = keyValue[1] < keyValue[0] ? keyValue[0] : keyValue[1];

			if (zipCodeMap.containsKey(key)) {

				value = (zipCodeMap.get(key) > value) ? zipCodeMap.get(key) : value;
			}
			zipCodeMap.put(key, value);

		}

		return filterZipCodeRange(zipCodeMap);

	}

	/**
	 * Validating the input range to check if the input digits in the set is 5
	 * digits or not If the digits is less than 5 digits, it throws an error.
	 * As per the requirements, rules for these restrictions are stored as a series of
	 * ranges of 5 digit codes
	 * 
	 * @param input
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	private static void validateZipCode(int[][] input) throws Exception {
		for (int i = 0; i < input.length; i++) {
			for (int j = 0; j < input[i].length; j++) {
				if (String.valueOf(input[i][j]).length() != 5) {
					throw new Exception("Not a valid Zip Code");
				}
			}
		}
	}

	/**
	 * 
	 * @param zipCodeMap
	 * @return
	 */
	private static int[][] filterZipCodeRange(TreeMap<Integer, Integer> zipCodeMap) {

		int prevKey = zipCodeMap.firstKey();
		int prevValue = zipCodeMap.get(prevKey);

		Set<Entry<Integer, Integer>> zipCodeSet = zipCodeMap.entrySet();

		Iterator<Entry<Integer, Integer>> iterator = zipCodeSet.iterator();

		while (iterator.hasNext()) {

			Map.Entry<Integer, Integer> entry = (Entry<Integer, Integer>) iterator.next();

			int key = (int) entry.getKey();
			int keyValue = (int) entry.getValue();
			if (key > prevKey && key <= prevValue + 1) {
				iterator.remove();
				if (keyValue > prevValue) {
					prevValue = keyValue;
					zipCodeMap.put(prevKey, prevValue);
				}
			} else {
				prevKey = key;
				prevValue = keyValue;
			}

		}
		return convertToArray(zipCodeMap);
	}

	/**
	 * Converting Map to Array
	 * 
	 * @param zipCodeMap
	 * @return
	 */
	private static int[][] convertToArray(TreeMap<Integer, Integer> zipCodeMap) {

		int[][] result = new int[zipCodeMap.size()][2];
		int index = 0;

		for (Map.Entry<Integer, Integer> entry : zipCodeMap.entrySet()) {

			result[index][0] = entry.getKey();
			result[index++][1] = entry.getValue();
		}

		return result;
	}
}
